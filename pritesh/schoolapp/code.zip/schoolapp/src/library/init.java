package library;

import android.app.Activity;


public class init extends Activity{
	public DatabaseHandler db= new DatabaseHandler(this);
	public UserFunctions uf = new UserFunctions();

}
